import decimal
import requests 
import requests_cache 
import json 
import os
from urllib.parse import urlparse
from pathlib import Path

requests_cache.install_cache('image_cache', backend='sqlite')
image_url_cache = {}

def get_image(search):
    print('Searching for image', search)
    if search in image_url_cache:
        print('Using cached image url')
        return image_url_cache[search]

    url = "https://google-search72.p.rapidapi.com/imagesearch"
    querystring = {"q": search, "gl": "us", "lr": "lang_en", "num": "10", "start": "0"}
    headers = {
        "X-RapidAPI-Key": "your_rapidapi_key",
        "X-RapidAPI-Host": "google-search72.p.rapidapi.com"
    }

    response = requests.get(url, headers=headers, params=querystring)
    data = response.json()

    img_url = ""

    if 'items' in data.keys():
        img_url = data['items'][0]['originalImageUrl']
        image_url_cache[search] = img_url
    
    print('Returned image url', img_url)
    return img_url


class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal): #if the object is a decimal we are going to encode it 
                return str(obj)
        return json.JSONEncoder(JSONEncoder, self).default(obj) #if not the JSONEncoder from json class can handle it 