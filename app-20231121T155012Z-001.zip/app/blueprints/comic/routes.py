from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from app.models import Comic, User, db

comic = Blueprint('comic', __name__, template_folder='comic_templates')

@comic.route('/comics/new', methods=['GET', 'POST'])
@login_required
def add_comic():
    if request.method == 'POST':
        # Extract data from form
        title = request.form.get('title')
        description = request.form.get('description')
        
        # Create new Comic instance
        new_comic = Comic(title=title, description=description, author=current_user)
        
        # Add to database
        db.session.add(new_comic)
        db.session.commit()
        
        flash('Comic added successfully!', 'success')
        return redirect(url_for('comic.view_comics'))
    
    return render_template('add_comic.html')

@comic.route('/comics')
def view_comics():
    comics = Comic.query.all()
    for comic_type in comics:
        comic_type.set_image(comic_type.title)
    return render_template('view_comics.html', comics=comics)

@comic.route('/comics/<int:comic_id>')
def comic_details(comic_id):
    comic_type = Comic.query.get_or_404(comic_id)
    comic_type.set_image(comic_type.title)
    return render_template('comic_details.html', comic=comic_type)

@comic.route('/comics/edit/<int:comic_id>', methods=['GET', 'POST'])
@login_required
def edit_comic(comic_id):
    comic_type = Comic.query.get_or_404(comic_id)

    if request.method == 'POST':
        comic_type.title = request.form.get('title')
        comic_type.description = request.form.get('description')
        comic_type.set_image(comic_type.title)
        
        db.session.commit()
        
        flash('Comic updated successfully!', 'success')
        return redirect(url_for('comic.comic_details', comic_id=comic_type.id))
    
    return render_template('edit_comic.html', comic=comic_type)

@comic.route('/comics/delete/<int:comic_id>', methods=['POST'])
@login_required
def delete_comic(comic_id):
    comic_type = Comic.query.get_or_404(comic_id)
    
    if comic_type.author != current_user:
        flash('You do not have permission to delete this comic.', 'error')
        return redirect(url_for('comic.view_comics'))

    db.session.delete(comic_type)
    db.session.commit()

    flash('Comic deleted successfully!', 'success')
    return redirect(url_for('comic.view_comics'))
