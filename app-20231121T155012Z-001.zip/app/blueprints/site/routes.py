from flask import Blueprint, render_template

site = Blueprint('site', __name__, template_folder='site_templates')

@site.route('/')
def home():
    return render_template('home.html')

@site.route('/about-me')
def about_me():
    return render_template('about_me.html')

@site.route('/coming-soon')
def coming_soon():
    return render_template('coming_soon.html')