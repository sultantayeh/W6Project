from werkzeug.security import generate_password_hash #generates a unique password hash for extra security 
from flask_sqlalchemy import SQLAlchemy #this is our ORM (Object Relational Mapper)
from flask_login import UserMixin, LoginManager #helping us load a user as our current_user 
from datetime import datetime #put a timestamp on any data we create (Users, Products, etc)
import uuid #makes a unique id for our data (primary key)
from flask_marshmallow import Marshmallow
from flask_login import UserMixin

#internal imports
from .helpers import get_image 

db = SQLAlchemy()
login_manager = LoginManager()
ma = Marshmallow()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256))
    date_joined = db.Column(db.DateTime, default=datetime.utcnow)
    comics = db.relationship('Comic', backref='author', lazy=True)

    def __init__(self, username, email, password, ):
        self.id = self.set_id()
        self.username = username
        self.email = email
        self.password = self.set_password(password)
        self.date_added = datetime.now()

    def set_id(self):
        return str(uuid.uuid4())
    
    def get_id(self):
        return str(self.id)
    
    def set_password(self, password):
        return generate_password_hash(password)
        
    def __repr__(self):
        return f"User('{self.username}', '{self.email}', '{self.date_joined}')"

class Comic(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(300), nullable=True)
    publish_date = db.Column(db.DateTime, default=datetime.utcnow)
    genre = db.Column(db.String(50), nullable=True)
    rating = db.Column(db.Integer, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def set_id(self):
        return str(uuid.uuid4())
    
    def __repr__(self):
        return f"Comic('{self.title}', '{self.description}', '{self.publish_date}', '{self.genre}', '{self.rating}')"
    
    def set_image(self, name):
        self.image = get_image(name) 